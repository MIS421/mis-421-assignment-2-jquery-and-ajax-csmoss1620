var len;
var results = '';

function apiSearch() {
  var params = {
    "q": $("#query").val(),
    "count": "50",
    "offset": "0",
    "mkt": "en-us"
    };


  $.ajax({
      url: 'https://api.bing.microsoft.com/v7.0/search?' + $.param(params),
      beforeSend: function (xhrObj) {
          xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", "636691e8647b40f18151bcbfbb6fcd6b");
      },
      type: "GET",
    })
    .done(function (data) {
      len = data.webPages.value.length;
      for (i = 0; i < len; i++) {
        results += "<p><a href='" + data.webPages.value[i].url + "'>" + data.webPages.value[i].name + "</a>: " + data.webPages.value[i].snippet + "</p>";
      }

      $('#search-results').html(results);
      $('#search-results').dialog();
    })
    .fail(function () {
      alert("error");
    });
}


function getTime(){
  var today = new Date();
      var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

      $('#currentTime').html(time);

      $('currentTime').dialog();
}